//ASSUME FIRST ELEMENT TO BE SORTED THEN INSERT FIRST ELEMENT OF THUS FORMED UNSORTED ARRAY TO ITS CORRECT POSITION.
//TIME COMPLEXITY - O(n^2).
//SPACE COMPLEXITY - O(1).

#include<bits/stdc++.h>

using namespace std;

int* TakeInput(int n)
{
	static int arr[INT_MAX];

	for(int i = 0; i < n; i++)
	{
		cin>>arr[i];
	}

	return arr;
}

void GiveOutput(int arr[], int n)
{
	for(int i = 0; i < n; i++)
	{
		cout<<arr[i]<<" ";
	}

	cout<<endl;
}

void InsertionSort(int arr[], int n)
{
	for(int i = 1; i < n; i++)
	{
		int current = arr[i], j = i - 1;

		while(arr[j] > current and j >= 0)
		{
			arr[j + 1] = arr[j];
			j--;
		}

		arr[j + 1] = current;
	}
}

int main()
{
	int n;

	cout<<"ENTER NUMBER OF ELEMENTS: ";
	cin>>n;

	cout<<"ENTER ELEMENTS OF ARRAY: ";
	int* arr = TakeInput(n);

	InsertionSort(arr, n);

	cout<<"SORTED ARRAY: ";
	GiveOutput(arr, n);

	return 0;
}