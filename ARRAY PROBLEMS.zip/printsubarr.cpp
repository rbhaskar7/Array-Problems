//PRINT ALL SUB-ARRAYS.
//TIME COMPLEXITY - O().
//SPACE COMPLEXITY - O().

#include<bits/stdc++.h>

using namespace std;

int* TakeInput(int n)
{
	static int arr[INT_MAX];

	for(int i = 0; i < n; i++)
	{
		cin>>arr[i];
	}

	return arr;
}

void PrintSubArray(int arr[], int n)
{
	int sub_arrays = 0;

	for(int i = 0; i < n; i++)
	{
		for(int j = i; j < n; j++)
		{
			sub_arrays++;
			cout<<"SUB-ARRAY "<<sub_arrays<<" : ";

			for(int k = i; k <= j; k++)
			{
				cout<<arr[k]<<" ";
			}

			cout<<endl;
		}
	}
}

int main()
{
	int n;

	cout<<"ENTER NUMBER OF ELEMENTS: ";
	cin>>n;

	cout<<"ENTER ELEMENTS OF ARRAY: ";
	int* arr = TakeInput(n);

	cout<<"ALL SUB-ARRAYS OF GIVEN ARRAY ->"<<endl;
	PrintSubArray(arr, n);

	return 0;
}