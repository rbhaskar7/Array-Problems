//FIND SUB-ARRAY WITH GIVEN SUM.
//TIME COMPLEXITY - O(n).
//SPACE COMPLEXITY - O(1).

#include<bits/stdc++.h>

using namespace std;

int* TakeInput(int n)
{
	static int arr[1001];

	for(int i = 0; i < n; i++)
	{
		cin>>arr[i];
	}

	return arr;
}

void FindSubArray(int arr[], int n, int S)
{
	int i = 0, j = 0, subarr_sum = 0, start = -1, end = -1;

	while(j < n and subarr_sum + arr[j] <= S)
	{
		subarr_sum += arr[j];
		j++;
	}

	if(subarr_sum == S)
	{
		start = i + 1;
		end = j;

		return;
	}
	else
	{
		while(j < n)
		{
			subarr_sum += arr[j];

			while(subarr_sum > S)
			{
				subarr_sum -= arr[i];
				i++;
			}

			if(subarr_sum == S)
			{
				start = i + 1;
				end = j + 1;

				break;
			}
			else
			{
				j++;
			}
		}
	}

	cout<<"START AND END INDICES OF REQUIRED SUB-ARRAY: "<<start<<" "<<end<<endl;
}

int main()
{
	int T;

	cout<<"ENTER NUMBER OF TEST CASES: ";
	cin>>T;

	for(int i = 0; i < T; i++)
	{
		cout<<"---TEST CASE "<<i + 1<<" ---"<<endl;

		int n, S;

		cout<<"ENTER NUMBER OF ELEMENTS: ";
		cin>>n;

		cout<<"ENTER ELEMENTS OF ARRAY: ";
		int* arr = TakeInput(n);

		cout<<"ENTER SUM S: ";
		cin>>S;

		FindSubArray(arr, n, S);

		cout<<"------------------"<<endl;
	}

	return 0;
}