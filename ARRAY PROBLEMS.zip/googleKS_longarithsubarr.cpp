//ARITHMETIC ARRAY IS WHEN DIFFERENCE BETWEEN ALL TERMS IS EQUAL.
//ITERATE THROUGH ALL ELEMENTS AND CHECK TILL WHEN DIFFERENCE IS SAME, UPTIL THEN THE LENGTH WILL BE MAXIMUM.
//TIME COMPLEXITY - O(n).
//SPACE COMPLEXITY - O(1).

#include<bits/stdc++.h>

using namespace std;

int* TakeInput(int n)
{
	static int arr[2000];

	for(int i = 0; i < n; i++)
	{
		cin>>arr[i];
	}

	return arr;
}

int FindMax_ArithSubArray(int arr[], int n)
{
	int max_length = 2, prev_diff = arr[1] - arr[0], curr_length = 2;

	for(int i = 2; i < n; i++)
	{
		if(prev_diff == arr[i] - arr[i - 1])
		{
			curr_length++;
		}
		else
		{
			prev_diff = arr[i] - arr[i - 1];
			curr_length = 2;
		}

		max_length = max(max_length, curr_length);
	}

	return max_length;
}

int main()
{
	int T;

	cout<<"ENTER NUMBER OF TEST CASES: ";
	cin>>T;

	for(int i = 0; i < T; i++)
	{
		cout<<"---TEST CASE "<<i + 1<<" ---"<<endl;

		int n;

		cout<<"ENTER NUMBER OF ELEMENTS: ";
		cin>>n;

		cout<<"ENTER ELEMENTS OF ARRAY: ";
		int* arr = TakeInput(n);

		cout<<"MAX ARITHMETIC SUB-ARRAY LENGTH: "<<FindMax_ArithSubArray(arr, n)<<endl;

		cout<<"------------------"<<endl;
	}

	return 0;
}