//FIND MAX ELEMENT TILL ith ELEMENT OF ARRAY.
//TIME COMPLEXITY - O(n)
//SPACE COMPLEXITY - O(1)

#include<bits/stdc++.h>

using namespace std;

int* TakeInput(int n)
{
	static int arr[INT_MAX];

	for(int i = 0; i < n; i++)
	{
		cin>>arr[i];
	}

	return arr;
}

void FindMax(int arr[], int n)
{
	int max_i = INT_MIN;

	for(int i = 0; i < n; i++)
	{
		max_i = max(max_i, arr[i]);
		cout<<"MAX ELEMENT TILL "<<i<<" POSITION: "<<max_i<<endl;
	}
}

int main()
{
	int n;

	cout<<"ENTER NUMBER OF ELEMENTS: ";
	cin>>n;

	cout<<"ENTER ELEMENTS OF THE ARRAY: ";
	int* arr = TakeInput(n);

	FindMax(arr, n);

	return 0;
}