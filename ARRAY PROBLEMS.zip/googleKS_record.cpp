//FIND MAX TILL ith ELEMENT THEN INCREMENT RECORD BREAKING DAYS IF BOTH CONDITIONS SATISFY.
//TIME COMPLEXITY - O(n).
//SPACE COMPLEXITY - O(1).

#include<bits/stdc++.h>

using namespace std;

int* TakeInput(int n)
{
	static int arr[1001];

	for(int i = 0; i < n; i++)
	{
		cin>>arr[i];
	}

	return arr;
}

int FindRecordDays(int arr[], int n)
{
	int record = 0, max_i = INT_MIN;
	
	arr[n] = -1;

	if(n == 1)
	{
		record = 1;
	}
	else
	{
		for(int i = 0; i < n; i++)
		{
			if(arr[i] > max_i and arr[i] > arr[i + 1])
			{
				record++;
			}

			max_i = max(max_i, arr[i]);
		}
	}

	return record;
}

int main()
{
	int T;

	cout<<"ENTER NUMBER OF TEST CASES: ";
	cin>>T;

	for(int i = 0; i < T; i++)
	{
		cout<<"---TEST CASE "<<i + 1<<" ---"<<endl;

		int n;

		cout<<"ENTER NUMBER OF ELEMENTS: ";
		cin>>n;

		cout<<"ENTER ELEMENTS OF ARRAY: ";
		int* arr = TakeInput(n);

		cout<<"NUMBER OF RECORD BREAKING DAYS: "<<FindRecordDays(arr, n)<<endl;

		cout<<"------------------"<<endl;
	}

	return 0;
}