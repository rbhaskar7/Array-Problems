//FIND SMALLEST POSITIVE MISSING NUMBER IN ARRAY.
//TIME COMPLEXITY - O(n).
//SPACE COMPLEXITY - O(1).

#include<bits/stdc++.h>

using namespace std;

int* TakeInput(int n)
{
	static int arr[1001];

	for(int i = 0; i < n; i++)
	{
		cin>>arr[i];
	}

	return arr;
}

int FindSmallestMissing(int arr[], int n)
{
	const int N = 1e6 + 2;
	vector<bool> check_min(N, false);
	int min_num = -1;

	for(int i = 0; i < n; i++)
	{
		if(arr[i] > 0)
		{
			check_min[arr[i]] = true;
		}
	}

	for(int i = 1; i < n; i++)
	{
		if(check_min[i] == false)
		{
			min_num = i;
			break;
		}
	}

	return min_num;
}

int main()
{
	int T;

	cout<<"ENTER NUMBER OF TEST CASES: ";
	cin>>T;

	for(int i = 0; i < T; i++)
	{
		cout<<"---TEST CASE "<<i + 1<<" ---"<<endl;

		int n;

		cout<<"ENTER NUMBER OF ELEMENTS: ";
		cin>>n;

		cout<<"ENTER ELEMENTS OF ARRAY: ";
		int* arr = TakeInput(n);

		cout<<"SMALLEST POSITIVE MISSING NUMBER: "<<FindSmallestMissing(arr, n)<<endl;

		cout<<"------------------"<<endl;
	}

	return 0;
}