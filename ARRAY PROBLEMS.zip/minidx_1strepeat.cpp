//FIND SMALLEST INDEX OF FIRST REPEATING ELEMENT IN ARRAY.
//TIME COMPLEXITY - O(n).
//SPACE COMPLEXITY - O(1).

#include<bits/stdc++.h>

using namespace std;

int* TakeInput(int n)
{
	static int arr[1001];

	for(int i = 0; i < n; i++)
	{
		cin>>arr[i];
	}

	return arr;
}

int FindSmallestIDX(int arr[], int n)
{
	vector<int> Index(1e6 + 2, -1);
	int min_index = INT_MAX;

	for(int i = 0; i < n; i++)
	{
		if(Index[arr[i]] != -1)
		{
			min_index = min(min_index, Index[arr[i]]);
		}
		else
		{
			Index[arr[i]] = i;
		}
	}

	if(min_index == INT_MAX)
	{
		min_index = -1;
	}
	else
	{
		min_index += 1;
	}

	return min_index;
}

int main()
{
	int T;

	cout<<"ENTER NUMBER OF TEST CASES: ";
	cin>>T;

	for(int i = 0; i < T; i++)
	{
		cout<<"---TEST CASE "<<i + 1<<" ---"<<endl;

		int n;

		cout<<"ENTER NUMBER OF ELEMENTS: ";
		cin>>n;

		cout<<"ENTER ELEMENTS OF ARRAY: ";
		int* arr = TakeInput(n);

		cout<<"SMALLEST INDEX OF ELEMENT THAT IS REPEATING: "<<FindSmallestIDX(arr, n)<<endl;

		cout<<"------------------"<<endl;
	}

	return 0;
}