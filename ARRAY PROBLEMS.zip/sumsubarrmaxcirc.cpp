//FIND MAX SUB-ARRAY SUM OF CIRCULAR ARRAY.
//ALGO:
//FIND MAX SUB-ARRAY SUM OF ARRAY WITHOUT CIRCLING.
//FIND MAX SUB-ARRAY SUM OF ARRAY WITH CIRCLING(USING KADANE ALGO ON REVERSE SIGNED ARRAY).
//FIND MAX OF BOTH.
//TIME COMPLEXITY - O(n).
//SPACE COMPLEXITY - O(1).

#include<bits/stdc++.h>

using namespace std;

int* TakeInput(int n)
{
	static int arr[INT_MAX];

	for(int i = 0; i < n; i++)
	{
		cin>>arr[i];
	}

	return arr;
}

//TO FIND MAX SUB-ARRAY SUM IN O(n).
int KadaneAlgo(int arr[], int n)
{
	int curr_sum = 0, max_sum = INT_MIN;

	for(int i = 0; i < n; i++)
	{
		curr_sum += arr[i];

		if(curr_sum < 0)
		{
			curr_sum = 0;
		}

		max_sum = max(max_sum, curr_sum);
	}

	return max_sum;
}

int FindMaxSubArrSum(int arr[], int n)
{
	int max_sum_norm, max_sum_circ, arr_sum = 0;

	max_sum_norm = KadaneAlgo(arr, n);

	for(int i = 0; i < n; i++)
	{
		arr_sum += arr[i];
		arr[i] = -arr[i];
	}

	max_sum_circ = arr_sum - (-KadaneAlgo(arr, n));

	return max(max_sum_norm, max_sum_circ);
}

int main()
{
	int n;

	cout<<"ENTER NUMBER OF ELEMENTS: ";
	cin>>n;

	cout<<"ENTER ARRAY ELEMENTS: ";
	int* arr = TakeInput(n);

	cout<<"MAXIMUM SUB-ARRAY SUM IS: "<<FindMaxSubArrSum(arr, n)<<endl;

	return 0;
}