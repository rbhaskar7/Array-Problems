//ITERATE THROUGH ALL SUB-ARRAYS AND FIND SUM AT EACH ITERATION.
//TIME COMPLEXITY - O(n)
//SPACE COMPLEXITY - O(1)

#include<bits/stdc++.h>

using namespace std;

int* TakeInput(int n)
{
	static int arr[INT_MAX];

	for(int i = 0; i < n; i++)
	{
		cin>>arr[i];
	}

	return arr;
}

void SubArraySum(int arr[], int n)
{
	int sub_arrays = 0, sub_array_max = INT_MIN;

	for(int i = 0; i < n; i++)
	{
		int current_sum = 0;

		for(int j = i; j < n; j++)
		{
			current_sum += arr[j];
			sub_arrays++;
			sub_array_max = max(sub_array_max, current_sum);
			cout<<"SUM OF SUB-ARRAY "<<sub_arrays<<" : "<<current_sum<<endl;
		}
	}

	cout<<"MAXIMUM SUM OF ALL SUB-ARRAY's SUM: "<<sub_array_max<<endl;
}

int main()
{
	int n;

	cout<<"ENTER NUMBER OF ELEMENTS: ";
	cin>>n;

	cout<<"ENTER ELEMENTS OF THE ARRAY: ";
	int* arr = TakeInput(n);

	SubArraySum(arr, n);

	return 0;
}