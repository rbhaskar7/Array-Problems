//FIND PAIRS SUCH THAT THEIR SUM IS EQUAL TO SOME K.
//ARRAY NEEDS TO BE SORTED.
//TIME COMPLEXITY - O(n).
//SPACE COMPLEXITY - O(n).

#include<bits/stdc++.h>

using namespace std;

bool IsSorted(int arr[], int n)
{
	arr[n] = INT_MAX;

	for(int i = 0; i < n; i++)
	{
		if(arr[i] > arr[i + 1])
		{
			return false;
		}
	}

	return true;
}

int* TakeInput(int n)
{
	static int arr[INT_MAX];

	for(int i = 0; i < n; i++)
	{
		cin>>arr[i];
	}

	return arr;
}

tuple<int, int> FindPair(int arr[], int n, int K)
{
	int low = 0, high = n - 1;

	if(IsSorted(arr, n))
	{
		while(low < high)
		{
			if(arr[low] + arr[high] == K)
			{
				return make_tuple(low + 1, high + 1); 
			}
			else if(arr[low] + arr[high] > K)
			{
				high--;
			}
			else
			{
				low++;
			}
		}

		if(low == high)
		{
			return make_tuple(-1, -1);
		}
		else
		{
			return make_tuple(low + 1, high + 1);
		}
	}
	else
	{
		int sorted[n];

		for(int i = 0; i < n; i++)
		{
			sorted[i] = arr[i];
		}

		sort(sorted, sorted + n);

		while(low < high)
		{
			if(sorted[low] + sorted[high] == K)
			{
				break; 
			}
			else if(sorted[low] + sorted[high] > K)
			{
				high--;
			}
			else
			{
				low++;
			}
		}

		if(low == high)
		{
			return make_tuple(-1, -1);
		}
		else
		{
			for(int i = 0; i < n; i++)
			{
				if(arr[i] == sorted[low])
				{
					low = i;
					break;
				}
			}

			for(int i = 0; i < n; i++)
			{
				if(arr[i] == sorted[high])
				{
					high = i;
					break;
				}
			}

			return make_tuple(low + 1, high + 1);
		}
	}
}

int main()
{
	int n, K, idx_1, idx_2;

	cout<<"NUMBER OF ELEMENTS: ";
	cin>>n;

	cout<<"ARRAY ELEMENTS: ";
	int* arr = TakeInput(n);

	cout<<"K: ";
	cin>>K;

	tie(idx_1, idx_2) = FindPair(arr, n, K);

	cout<<"INDICES OF REQUIRED PAIR: ("<<idx_1<<", "<<idx_2<<")"<<endl;

	return 0;
}