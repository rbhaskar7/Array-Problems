//FIND MINIMUM ELEMENT AND SWAP WITH FIRST ELEMENT OF UNSORTED ARRAY.
//TIME COMPLEXITY - O(n^2).
//SPACE COMPLEXITY - O(1).

#include<bits/stdc++.h>

using namespace std;

void Swap(int x, int y)
{
	int temp = x;
	x = y;
	y = temp;
}

int* TakeInput(int n)
{
	static int arr[INT_MAX];

	for(int i = 0; i < n; i++)
	{
		cin>>arr[i];
	}

	return arr;
}

void GiveOutput(int arr[], int n)
{
	for(int i = 0; i < n; i++)
	{
		cout<<arr[i]<<" ";
	}

	cout<<endl;
}

void SelectionSort(int arr[], int n)
{
	for(int i = 0; i < n - 1; i++)
	{
		for(int j = i + 1; j < n; j++)
		{
			if(arr[j] < arr[i])
			{
				swap(arr[j], arr[i]);
			}
		}
	}
}

int main()
{
	int n;

	cout<<"ENTER NUMBER OF ELEMENTS: ";
	cin>>n;

	cout<<"ENTER ELEMENTS OF ARRAY: ";
	int* arr = TakeInput(n);

	SelectionSort(arr, n);

	cout<<"SORTED ARRAY: ";
	GiveOutput(arr, n);

	return 0;
}