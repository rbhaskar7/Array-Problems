//SWAP ADJACENT ELEMENTS IF THEY ARE IN WRONG ORDER.
//TIME COMPLEXITY - O(n^2).
//SPACE COMPLEXITY - O(1).

#include<bits/stdc++.h>

using namespace std;

void Swap(int x, int y)
{
	int temp = x;
	x = y;
	y = temp;
}

int* TakeInput(int n)
{
	static int arr[INT_MAX];

	for(int i = 0; i < n; i++)
	{
		cin>>arr[i];
	}

	return arr;
}

void GiveOutput(int arr[], int n)
{
	for(int i = 0; i < n; i++)
	{
		cout<<arr[i]<<" ";
	}

	cout<<endl;
}

void InsertionSort(int arr[], int n)
{
	int counter = 1;

	while(counter < n)
	{
		for(int i = 0; i < n - counter; i++)
		{
			if(arr[i] > arr[i + 1])
			{
				swap(arr[i], arr[i + 1]);
			}
		}

		counter++;
	}
}

int main()
{
	int n;

	cout<<"ENTER NUMBER OF ELEMENTS: ";
	cin>>n;

	cout<<"ENTER ELEMENTS OF ARRAY: ";
	int* arr = TakeInput(n);

	InsertionSort(arr, n);

	cout<<"SORTED ARRAY: ";
	GiveOutput(arr, n);

	return 0;
}